package za.ac.cput.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.ac.cput.domain.Contact;
import za.ac.cput.repository.ContactRepository;

import java.util.Set;
import java.util.stream.Collectors;

@Service
public class ContactService implements IService<Contact, Long> {

    private final ContactRepository contactRepository;

    @Autowired
    public ContactService(ContactRepository contactRepository) {
        this.contactRepository = contactRepository;
    }

    @Override
    public Contact create(Contact contact) {
        return contactRepository.save(contact);
    }

    @Override
    public Contact read(Long contactId) {
        return contactRepository.findById(contactId).orElse(null);
    }

    @Override
    public Contact update(Contact contact) {
        if (contactRepository.existsById(contact.getContactId())) {
            return contactRepository.save(contact);
        }
        return null;
    }

    @Override
    public void delete(Long contactId) {
        if (contactRepository.existsById(contactId)) {
            contactRepository.deleteById(contactId);
        }
    }

    public Set<Contact> getAll() {
        return contactRepository.findAll().stream().collect(Collectors.toSet());
    }
}
