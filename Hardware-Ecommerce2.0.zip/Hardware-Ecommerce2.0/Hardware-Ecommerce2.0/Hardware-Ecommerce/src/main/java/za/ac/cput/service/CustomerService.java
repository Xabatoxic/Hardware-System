package za.ac.cput.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import za.ac.cput.domain.Address;
import za.ac.cput.domain.Contact;
import za.ac.cput.domain.Customer;
import za.ac.cput.repository.CustomerRepository;
import za.ac.cput.util.Helper;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class CustomerService implements ICustomerService {
    private final CustomerRepository customerRepository;

    @Autowired
    CustomerService(CustomerRepository customerRepository) {

        this.customerRepository = customerRepository;
    }

    @Autowired
    private PasswordEncoder passwordEncoder;


    @Override
    public Customer create(Customer customer) {
        customer.setRole("customer");
        customer.setEmail(customer.getContact().getEmail());
        return customerRepository.save(customer);
    }

    @Override
    public Customer read(Long id) {
        return customerRepository.findById(id).orElse(null);
    }

    @Override
    public Customer update(Customer customer) {
        if (customerRepository.existsById(customer.getUserId())) {
            return customerRepository.save(customer);
        }
        return null;
    }

    @Override
    public void delete(Long id) {
        customerRepository.deleteById(id);
    }

    @Override
    public Set<Customer> getAll() {
        return customerRepository.findAll().stream().collect(Collectors.toSet());

    }

    public List<Customer> getAllCustomersByRole() {
        return customerRepository.findAllCustomersByRole();
    }

    @Override
    public Customer findByUsernameAndPassword(String username, String password) {
        return customerRepository.findByUserNameAndPassword(username, password);
    }

    public Customer partialUpdate(Customer customer) {
        Optional<Customer> existingCustomerOptional = customerRepository.findById(customer.getUserId());
        if (existingCustomerOptional.isPresent()) {
            Customer existingCustomer = existingCustomerOptional.get();

            Customer.CustomerBuilder builder = existingCustomer.copy().toBuilder();

//            if (customer.getFirstName() != null) {
//                builder.firstName(customer.getFirstName());
//            }
//            if (customer.getLastName() != null) {
//                builder.lastName(customer.getLastName()
//                );
//            }
            if (customer.getUserName() != null) {
                builder.userName(customer.getUserName());
            }
            if (customer.getPassword() != null) {
                builder.password(customer.getPassword());
            }
            if (customer.getRole() != null) {
                builder.role(customer.getRole());
            }
            if (customer.getContact() != null) {
                Contact existingContact = existingCustomer.getContact();
                Contact newContact = customer.getContact();
                Contact.ContactBuilder contactBuilder = newContact.copy().toBuilder();

                if (newContact.getEmail() != null) {
                    contactBuilder.email(newContact.getEmail());
                }
                if (newContact.getPhoneNumber() != null) {
                    contactBuilder.phoneNumber(newContact.getPhoneNumber());
                }

                builder.contact(contactBuilder.build());
            }
            if (customer.getAddresses() != null) {
                List<Address> existingAddresses = existingCustomer.getAddresses();
                List<Address> newAddresses = customer.getAddresses();
                builder.addresses(newAddresses != null ? newAddresses : existingAddresses);
            }

            return customerRepository.save(builder.build());
        }
        return null;
    }

    public Customer login(String email, String rawPassword) {
        Customer customer = customerRepository.findByContactEmail(email);

        // Check if customer exists and if the provided password matches the hashed password
        if (customer != null && passwordEncoder.matches(rawPassword, customer.getPassword())) {
            return customer;
        } else {
            return null; // If authentication fails, return null
        }
    }

}