package za.ac.cput.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.ac.cput.domain.Address;
import za.ac.cput.repository.AddressRepository;

import java.util.Set;
import java.util.stream.Collectors;

@Service
public class AddressService implements IService<Address, String> {

    private final AddressRepository addressRepository;

    @Autowired
    public AddressService(AddressRepository addressRepository) {
        this.addressRepository = addressRepository;
    }

    @Override
    public Address create(Address address) {
        return addressRepository.save(address);
    }

    @Override
    public Address read(String streetNumber) {
        return addressRepository.findById(Long.valueOf(streetNumber)).orElse(null);
    }

    @Override
    public Address update(Address address) {
        if (addressRepository.existsById(Long.valueOf(address.getStreetNumber()))) {
            return addressRepository.save(address);
        }
        return null;
    }

    @Override
    public void delete(String streetNumber) {
        if (addressRepository.existsById(Long.valueOf(streetNumber))) {
            addressRepository.deleteById(Long.valueOf(streetNumber));
        }
    }

    public Set<Address> getAll() {
        return addressRepository.findAll().stream().collect(Collectors.toSet());
    }
}