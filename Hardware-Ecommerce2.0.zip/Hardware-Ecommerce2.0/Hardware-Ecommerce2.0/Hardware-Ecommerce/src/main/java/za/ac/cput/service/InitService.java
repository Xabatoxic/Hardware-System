package za.ac.cput.service;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import za.ac.cput.domain.Contact;
import za.ac.cput.domain.Customer;
import za.ac.cput.repository.CustomerRepository;

@Service
public class InitService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;  // Inject PasswordEncoder



    @PostConstruct
    public void init() {
        if (customerRepository.findByUserName("admin") == null) {
            // Create and save the customer
            Contact contact = Contact.builder()
                    .email("admin@gmail.com")
                    .phoneNumber("1234567890")
                    .build();

            // Encrypt the password before saving
            String encodedPassword = passwordEncoder.encode("admin123");

            Customer customer = Customer.builder()
                    .userName("admin")
                    .password(encodedPassword)
                    .email("admin@gmail.com")
                    .role("admin")
                    .firstName("admin")
                    .lastName("admin")
                    .surname("admin")
                    .contact(contact)
                    .build();

            customerRepository.save(customer);

        } else {
          // do nothing
        }
    }
}
