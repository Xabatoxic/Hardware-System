package za.ac.cput.factory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import za.ac.cput.domain.Address;
import za.ac.cput.domain.Contact;
import za.ac.cput.domain.Customer;
import za.ac.cput.repository.CustomerRepository;
import za.ac.cput.util.AddressHelper;
import za.ac.cput.util.ContactHelper;
import za.ac.cput.util.Helper;

import java.util.Collections;
import java.util.List;

@Service

public class CustomerFactory {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;  // Inject PasswordEncoder



    public Customer createCustomer1(String username , String surname,String password, String role) {
        if ( Helper.isNullOrEmpty(username)  || Helper.isNullOrEmpty(password) || Helper.isNullOrEmpty(role)) {

            throw new IllegalArgumentException(
                    "Can not have null or empty values in required fields!!!");
        }
        System.out.println("Password to be encrypted is :"+password);
        String encodedPassword = passwordEncoder.encode(password);

        Contact contact = Contact.builder()
                .email(username)
                .build();

        return  Customer.builder()
                .contact(contact)
                .role("customer")
                .userName(username)
                .surname(surname)
                .password(encodedPassword)
                .role(role)
                .build();
    }


    public static Customer createCustomer2(String username, String surname, String firstname, String lastname, Contact contact, String password, String role, List <Address> addresses) {

        if (addresses == null) {
            addresses = Collections.emptyList();
        }

        PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String hashedPass =  passwordEncoder.encode(password);

        return  Customer.builder()
                .userName(username)
                .firstName(firstname)
                .lastName(lastname)
                .contact(contact)
                .password(hashedPass)
                .role(role)
                .addresses(addresses)
                .build();
    }


    public Customer login(String email, String password) {
        return customerRepository.findByContactEmailAndPassword(email, password);
    }

}

