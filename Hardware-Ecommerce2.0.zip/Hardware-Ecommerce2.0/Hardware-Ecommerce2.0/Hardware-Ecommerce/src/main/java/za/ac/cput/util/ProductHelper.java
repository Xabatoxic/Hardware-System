package za.ac.cput.util;

public class ProductHelper {
    public static boolean isValidPrice(float price) {
        return price > 0;
    }

    // Add more validation methods as needed
}