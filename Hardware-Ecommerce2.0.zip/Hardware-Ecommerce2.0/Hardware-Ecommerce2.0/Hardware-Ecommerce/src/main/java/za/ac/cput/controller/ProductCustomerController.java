package za.ac.cput.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import za.ac.cput.domain.ProductCustomer;
import za.ac.cput.repository.ProductCustomerRepository;
import za.ac.cput.service.ProductCustomerService;

import java.util.List;

@RestController
@RequestMapping("/api/product-customer")
public class ProductCustomerController {

    @Autowired
    private ProductCustomerService productCustomerService;
    @Autowired
    private ProductCustomerRepository productCustomerRepository;


    @PostMapping("/create")
    public ResponseEntity<ProductCustomer> createProductCustomer(@RequestParam Long customerId, @RequestParam Long productId) {
        ProductCustomer productCustomer = productCustomerService.createProductCustomer(customerId, productId);
        return ResponseEntity.ok(productCustomer);
    }


    @GetMapping("/unprocessed")
    public ResponseEntity<List<ProductCustomer>> getUnprocessedProductsByCustomer(@RequestParam("customerId") Integer customerId) {
        List<ProductCustomer> unprocessedProducts = productCustomerService.getUnprocessedProductsByCustomerId(customerId);
        return ResponseEntity.ok(unprocessedProducts);
    }

    @PutMapping("/proceed")
    public ResponseEntity<String> updateIsProductProceed(@RequestBody List<Integer> productCustomerIds) {
        productCustomerService.updateIsProductProceed(productCustomerIds);
        return ResponseEntity.ok("Product proceed status updated successfully");
    }

    @GetMapping("/all")
    public ResponseEntity<List<ProductCustomer>> getAllProductCustomers() {
        List<ProductCustomer> productCustomers = productCustomerRepository.findAll();
        return ResponseEntity.ok(productCustomers);
    }



    @GetMapping("/done-processed")
    public ResponseEntity<List<ProductCustomer>> getProcessedProductsByCustomerId(@RequestParam("customerId") Integer customerId) {
        List<ProductCustomer> unprocessedProducts = productCustomerService.getProcessedProductsByCustomerId(customerId);
        return ResponseEntity.ok(unprocessedProducts);
    }


    @GetMapping("/proceeded")
    public ResponseEntity<List<ProductCustomer>> getAllProductCustomersWithProceedTrue() {
        List<ProductCustomer> productCustomers = productCustomerService.getAllProductCustomersWithProceedTrue();
        return ResponseEntity.ok(productCustomers);
    }


}
