package za.ac.cput.domain;

import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;

@Entity
@Table(name = "orders")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class Order implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "order_id")
    private long orderId;

    @OneToOne
    @JoinColumn(name = "cart_id", referencedColumnName = "cartId", nullable = false)  // Updated to standard snake_case
    private Cart cart;

    @Column(name = "order_date", nullable = false)
    private LocalDate orderDate;

    @Column(name = "total_amount", columnDefinition = "DECIMAL(7,2)")
    private BigDecimal totalAmount;

    @Column(name = "user_id", nullable = false)  // Updated for consistency
    private Long userId;

    @Column(name = "order_number", nullable = false, unique = true)  // Renamed from orderID to orderNumber
    private String orderNumber;

    @PrePersist
    @PreUpdate
    private void updateTotalAmount() {
        calculateTotalAmount();
    }

    public void calculateTotalAmount() {
        if (cart != null && cart.getTotalPrice() != null) {
            totalAmount = cart.getTotalPrice().setScale(2, RoundingMode.HALF_UP);
        } else {
            totalAmount = BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
        }
    }
}


