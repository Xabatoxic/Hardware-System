//package za.ac.cput.domain;
//
//public enum OrderStatus {
//    PENDING, SHIPPED, DELIVERED, CANCELLED,IN_TRANSIT
//}