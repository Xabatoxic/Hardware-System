
package za.ac.cput.domain;
import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "carts")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@ToString
@EqualsAndHashCode
public class Cart implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long cartId;

    @OneToOne
    @JoinColumn(name = "userID")
    private Customer customer;


    private int itemsQuantity;





    @OneToMany(mappedBy = "cart", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CartItem> cartItems = new ArrayList<>();


    @Column(columnDefinition = "DECIMAL(7,2)")
    private BigDecimal totalPrice;

    @Column(name = "orderID", nullable = true)
    private String orderID;

    public void addItem(CartItem item) {
        cartItems.add(item);
        item.setCart(this);
        updateItemsQuantity();
        calculateTotalPrice();
    }

    public void removeItem(CartItem item) {
        cartItems.remove(item);
        item.setCart(null);
        updateItemsQuantity();
        calculateTotalPrice();
    }

    public void calculateTotalPrice() {
        totalPrice = cartItems.stream()
                .map(CartItem::getPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(2, RoundingMode.HALF_UP);
    }

    private void updateItemsQuantity() {
        itemsQuantity = cartItems.size();
    }

}


