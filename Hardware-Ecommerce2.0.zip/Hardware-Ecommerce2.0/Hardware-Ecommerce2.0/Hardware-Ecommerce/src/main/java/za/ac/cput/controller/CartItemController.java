package za.ac.cput.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import za.ac.cput.domain.CartItem;
import za.ac.cput.service.CartItemService;
import java.util.Set;

@RestController
@RequestMapping("/cart-items")
public class CartItemController {

    private final CartItemService cartItemService;

    @Autowired
    public CartItemController(CartItemService cartItemService) {
        this.cartItemService = cartItemService;
    }

    @PostMapping("/create")
    public CartItem createCartItem(@RequestBody CartItem cartItem) {
        return cartItemService.create(cartItem);
    }

    @GetMapping("/read/{id}")
    public CartItem readCartItem(@PathVariable Long id) {
        return cartItemService.read(id);
    }

    @PutMapping("/update")
    public CartItem updateCartItem(@RequestBody CartItem cartItem) {
        return cartItemService.update(cartItem);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteCartItem(@PathVariable Long id) {
        cartItemService.delete(id);
    }

    @GetMapping("/all")
    public Set<CartItem> getAllCartItems() {
        return cartItemService.getAll();
    }
}

