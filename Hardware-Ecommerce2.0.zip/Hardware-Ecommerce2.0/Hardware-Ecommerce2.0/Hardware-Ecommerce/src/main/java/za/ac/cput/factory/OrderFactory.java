package za.ac.cput.factory;

import za.ac.cput.domain.Cart;
import za.ac.cput.domain.Order;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;

public class OrderFactory {

    public static Order buildOrder(Cart cart, LocalDate orderDate, BigDecimal totalAmount) {
        if (cart == null || orderDate == null || totalAmount == null) {
            throw new IllegalArgumentException("Invalid parameters");
        }

        return Order.builder()
                .cart(cart)
                .orderDate(orderDate)
                .totalAmount(totalAmount.setScale(2, RoundingMode.HALF_UP))
                .build();
    }
}