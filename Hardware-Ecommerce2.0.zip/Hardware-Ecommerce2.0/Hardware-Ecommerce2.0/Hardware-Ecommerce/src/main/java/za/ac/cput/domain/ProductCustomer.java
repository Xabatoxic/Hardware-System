package za.ac.cput.domain;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Table(name = "productsCustomers")
@Entity
@Setter
@Getter

public class ProductCustomer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private Boolean isProductProceed;

    @Column(name = "date")
    private Date date;

    @ManyToOne
    Customer customer;

    @ManyToOne
    Product product;



}
