package za.ac.cput.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import za.ac.cput.domain.ProductCustomer;

import java.util.List;

@Repository
public interface ProductCustomerRepository extends JpaRepository<ProductCustomer, Integer> {

    // Custom query to fetch products where isProductProceed is false and filter by customerId
    @Query("SELECT pc FROM ProductCustomer pc WHERE pc.isProductProceed = false AND pc.customer.id = :customerId")
    List<ProductCustomer> findUnproceededProductsByCustomerId(Integer customerId);

    @Query("SELECT pc FROM ProductCustomer pc WHERE pc.isProductProceed = true AND pc.customer.id = :customerId")
    List<ProductCustomer> findProceededProductsByCustomerId(Integer customerId);

    @Query("SELECT pc FROM ProductCustomer pc WHERE pc.isProductProceed = true")
    List<ProductCustomer> findAllByIsProductProceedTrue();


}
