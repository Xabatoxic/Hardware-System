// CustomerController.java
package za.ac.cput.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import za.ac.cput.domain.Customer;
import za.ac.cput.factory.CustomerFactory;
import za.ac.cput.service.CustomerService;

import java.util.List;
import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping("/customer")
public class CustomerController {
    @Autowired
    private CustomerService customerService;




    @PostMapping("/create")
    public Customer create(@RequestBody Customer customer) {
        // Assuming the customer is created with factory method before passing to the service
        Customer createdCustomer = CustomerFactory.createCustomer2(
                customer.getUserName(),
                customer.getSurname(),
                customer.getFirstName(),
                customer.getLastName(),
                customer.getContact(),
                customer.getPassword(),
                customer.getRole(),
                customer.getAddresses()
        );
        createdCustomer.setRole("customer");

        if (createdCustomer == null) {
            throw new IllegalArgumentException("Invalid customer data, please make sure to add all the required data");
        }
        System.out.println("Customer email is "+ customer.getContact().getEmail());
        return customerService.create(createdCustomer);
    }






    @GetMapping("/read/{id}")
    public Customer read(@PathVariable Long id) {
        return customerService.read(id);
    }

    @PutMapping("/update")
    public Customer update(@RequestBody Customer customer) {
        return customerService.partialUpdate(customer);
    }

    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id) {
        customerService.delete(id);
    }

    @GetMapping("/getAll")
    public List<Customer> getAll() {
        return customerService.getAllCustomersByRole();
    }


    @PostMapping("/login")
    public ResponseEntity<Customer> login(@RequestBody Map<String, String> loginDetails) {
        String email = loginDetails.get("email");
        String password = loginDetails.get("password");

        Customer customer = customerService.login(email, password);
        if (customer != null) {
            return ResponseEntity.ok(customer);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);  // Return unauthorized status if login fails
        }
    }




}