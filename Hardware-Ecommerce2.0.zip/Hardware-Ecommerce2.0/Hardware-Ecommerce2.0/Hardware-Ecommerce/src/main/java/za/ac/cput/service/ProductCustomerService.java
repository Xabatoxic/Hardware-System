package za.ac.cput.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.ac.cput.domain.Customer;
import za.ac.cput.domain.Product;
import za.ac.cput.domain.ProductCustomer;
import za.ac.cput.repository.CustomerRepository;
import za.ac.cput.repository.ProductCustomerRepository;
import za.ac.cput.repository.ProductRepository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class ProductCustomerService {

    @Autowired
    private ProductCustomerRepository productCustomerRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private ProductRepository productRepository;


    public ProductCustomer createProductCustomer(Long customerId, Long productId) {


        Optional<Customer> customerOptional = customerRepository.findById(customerId);
        Optional<Product> productOptional = productRepository.findById(productId);

        if (customerOptional.isPresent() && productOptional.isPresent()) {
            Customer customer = customerOptional.get();
            Product product = productOptional.get();

            ProductCustomer productCustomer = new ProductCustomer();
            productCustomer.setCustomer(customer);
            productCustomer.setProduct(product);
            productCustomer.setDate(new Date());
            productCustomer.setIsProductProceed(false);

            return productCustomerRepository.save(productCustomer);
        } else {
            throw new IllegalArgumentException("Customer or Product not found with the provided IDs.");
        }
    }



    // Method to fetch unprocessed products for a customer
    public List<ProductCustomer> getUnprocessedProductsByCustomerId(Integer customerId) {
        return productCustomerRepository.findUnproceededProductsByCustomerId(customerId);
    }


    // Method to update isProductProceed for all provided productCustomer IDs
    public void updateIsProductProceed(List<Integer> productCustomerIds) {
        List<ProductCustomer> productCustomers = productCustomerRepository.findAllById(productCustomerIds);

        for (ProductCustomer productCustomer : productCustomers) {
            productCustomer.setIsProductProceed(true); // Update field to true
        }

        // Save all updated entities
        productCustomerRepository.saveAll(productCustomers);
    }



    // Method to fetch unprocessed products for a customer
    public List<ProductCustomer> getProcessedProductsByCustomerId(Integer customerId) {
        return productCustomerRepository.findProceededProductsByCustomerId(customerId);
    }


    public List<ProductCustomer> getAllProductCustomersWithProceedTrue() {
        return productCustomerRepository.findAllByIsProductProceedTrue();
    }



}
