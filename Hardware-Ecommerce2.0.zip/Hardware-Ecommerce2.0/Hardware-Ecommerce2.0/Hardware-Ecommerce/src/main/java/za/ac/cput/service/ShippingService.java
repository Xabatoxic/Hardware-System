//package za.ac.cput.service;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import za.ac.cput.repository.ShippingRepository;
//
//import java.util.Set;
//import java.util.stream.Collectors;
//
//@Service
//public class ShippingService implements IShippingService {
//
//    private final ShippingRepository shippingRepository;
//
//    @Autowired
//    public ShippingService(ShippingRepository shippingRepository) {
//        this.shippingRepository = shippingRepository;
//    }
//
//    @Override
//    public Shipping create(Shipping shipping) {
//        return shippingRepository.save(shipping);
//    }
//
//    @Override
//    public Shipping read(Long id) {
//        return shippingRepository.findById(id).orElse(null);
//    }
//
//    @Override
//    public Shipping update(Shipping shipping) {
//        return shippingRepository.save(shipping);
//    }
//
//    @Override
//    public void delete(Long id) {
//        shippingRepository.deleteById(id);
//    }
//
//    @Override
//    public Set<Shipping> getAll() {
//        return shippingRepository.findAll().stream().collect(Collectors.toSet());
//    }
//}


