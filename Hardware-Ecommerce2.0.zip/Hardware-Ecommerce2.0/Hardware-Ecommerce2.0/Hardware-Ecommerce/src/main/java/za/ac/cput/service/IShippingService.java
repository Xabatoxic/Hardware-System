//package za.ac.cput.service;
//
//import za.ac.cput.domain.Shipping;
//
//import java.util.Set;
//
//public interface IShippingService extends IService<Shipping, Long> {
//    Set<Shipping> getAll();
//}

